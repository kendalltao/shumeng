#!/usr/bin/env python3
import latticex.rosetta as rtt
import tensorflow as tf


# You can activate a backend protocol, here we use SecureNN
rtt.activate("SecureNN")

for i in range(2):

    # Get private data from every party
    Input1 = tf.Variable(rtt.private_input(0,[[1],[8],[-40],[-2]]))
    Input2 = tf.Variable(rtt.private_input(1,[[-30],[0],[0],[1]]))
    # Input3 = tf.Variable(rtt.private_console_input(2))

    # juzhen1 = tf.constant([1,0,0,0],shape=(1,4))  
    # juzhen2 = tf.constant([0,0,1,0],shape=(1,4))  


    # # x1 x3 x5 in ciphertext
    # flag1 = tf.matmul(juzhen1, Input1)
    # flag2 = tf.matmul(juzhen2, Input1)
    # flag3 = tf.matmul(juzhen1, Input2)

    x1 = Input1[0][0]
    x2 = Input1[1][0]
    x3 = Input1[2][0]
    x4 = Input1[3][0]
    x5 = Input2[0][0]
    x6 = Input2[1][0]
    x7 = Input2[2][0]
    x8 = Input2[3][0] 


    res1 = tf.greater(0,x1)
    res2 = tf.greater(0,x3)
    res3 = tf.greater(0,x5)
    res4 = tf.greater_equal((-50),x3)
    res5 = tf.greater_equal((-30),x3)

    # run computation
    with tf.Session() as sess:
        sess.run(tf.global_variables_initializer())
        res1 = sess.run(res1)
        res2 = sess.run(res2)
        res3 = sess.run(res3)
        res4 = sess.run(res4)
        res5 = sess.run(res5)

        print("res1:",res1)
        print("res2:",res2)
        print("res3:",res3)
        print("res4:",res4)
        print("res5:",res5)
        print("0:",tf.Variable(rtt.private_input(0,[[0]])))
        print("1:",tf.Variable(rtt.private_input(0,[[1]])))
        print("0:",tf.Variable(rtt.private_input(1,[[0]])))
        print("1:",tf.Variable(rtt.private_input(1,[[1]])))



        # whether x1 x3 x5<0
        temp1 = float(sess.run(rtt.SecureReveal(res1))[0][0])
        temp2 = float(sess.run(rtt.SecureReveal(res2))[0][0])
        temp3 = float(sess.run(rtt.SecureReveal(res3))[0][0])
        temp4 = float(sess.run(rtt.SecureReveal(res4))[0][0])
        temp5 = float(sess.run(rtt.SecureReveal(res5))[0][0])


    # calculate p1 and p2
    p1 = 1.0
    if temp1 == 1.0:  #if x1<0
        p1 *=1.5
    # if temp2 == 1.0:  #if x3<0
    #     p1 *=1.5

    # p2 = 1.0
    # if temp1 == 1.0:  #if x1<0
    #     p2 *=1.5
    # if temp3 == 1.0:        #if x5<0
    #     p2 *=1.1
    # if temp4 == 1.0:     #if x3<=-50
    #     p2 *=1.2
    # elif temp5 == 1.0:   #if x3<=-30
    #     p2 *=1.1


    print ('p1:',p1)
    # print ('p2:',p2)

    



