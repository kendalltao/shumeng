#!/usr/bin/env python3

import latticex.rosetta as rtt
import tensorflow as tf
import pandas as pd
import numpy as np
import numba
from numba import jit

data = pd.read_csv("demo_data.csv")

data1 = data["法院严重失信主体"]
data2 = data["法院其他得分总计"]
data3 = data["公安处罚得分"]
data4 = data["公安其他得分总计"]
data5 = data["应急证件得分"]
data6 = data["应急其他得分总计"]
data7 = data["税务级别得分"]
data8 = data["税务其他得分总计"]

data_1 = []
data_2 = []
data_3 = []
data_4 = []
data_5 = []
data_6 = []
data_7 = []
data_8 = []

for i in range(len(data1)):
    data_1.append(data1[i])

for i in range(len(data2)):
    data_2.append(data2[i])

for i in range(len(data3)):
    data_3.append(data3[i])

for i in range(len(data4)):
    data_4.append(data4[i])

for i in range(len(data5)):
    data_5.append(data5[i])

for i in range(len(data6)):
    data_6.append(data6[i])

for i in range(len(data7)):
    data_7.append(data7[i])

for i in range(len(data8)):
    data_8.append(data8[i])


# You can activate a backend protocol, here we use SecureNN
rtt.activate("SecureNN")

# Get private data from every party

# Input1 = tf.Variable(rtt.private_input(0,[[0],[8],[0],[-2]]))
# Input2 = tf.Variable(rtt.private_input(1,[[-30],[0],[0],[-1]]))

tt = []

def tty(a,b,c,d,e,f,g,h,temp):
    for i in range(0,temp):  #replace 0 50000  100000
        Input1 = tf.Variable(rtt.private_input(0,[[a[i]],[b[i]],[c[i]],[d[i]]]))
        Input2 = tf.Variable(rtt.private_input(1,[[e[i]],[f[i]],[g[i]],[h[i]]]))


        x1 = Input1[0][0]
        x2 = Input1[1][0]
        x3 = Input1[2][0]
        x4 = Input1[3][0]
        x5 = Input2[0][0]
        x6 = Input2[1][0]
        x7 = Input2[2][0]
        x8 = Input2[3][0]

        res1 = tf.less(x1,0)
        res2 = tf.less(x3,0)
        res3 = tf.less(x5,0)
        res4 = tf.greater_equal((-50),x3)
        res5 = tf.greater_equal((-30),x3) 


        p2 = p1 = tf.add(tf.multiply(res1,0.5),1.0)
        p1 = tf.multiply(p1,tf.add(tf.multiply(res2,0.5),1.0))
        p2 = tf.multiply(p2,tf.add(tf.multiply(res3,0.1),1.0))
        p2 = tf.multiply(p2,tf.add(tf.add(tf.multiply(res4,0.1),tf.multiply(res5,0.1)),1.0))

        cipher_result = tf.add(tf.add(tf.add(tf.add(tf.add(tf.add(tf.add(tf.add(600,x1),x2),x3),x4),tf.multiply(p1,x5)),x6),tf.multiply(p2,x7)),x8)

        tt.append(cipher_result)


tty(data_1,data_2,data_3,data_4,data_5,data_6,data_7,data_8,100)



# tty(data_1,data_2,data_3,data_4,data_5,data_6,data_7,data_8,10)


with tf.Session() as sess:
    sess.run(tf.global_variables_initializer())

    # Set only party a and b can get plain result
    a_and_b_can_get_plain = 0b011
    print('plaintext matmul result:', sess.run(
        rtt.SecureReveal(tt[0], a_and_b_can_get_plain)))